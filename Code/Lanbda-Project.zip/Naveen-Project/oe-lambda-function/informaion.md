## Performing Route 53 health checks on private resources in a VPC with AWS Lambda and Amazon CloudWatch
https://aws.amazon.com/blogs/networking-and-content-delivery/performing-route-53-health-checks-on-private-resources-in-a-vpc-with-aws-lambda-and-amazon-cloudwatch/

## Security Group for Lambda
Security group name - oe-lambda-sg
VPC - ameintu-vpc

## Lambda Function 
Function Name - oe-lambda-function
Runtime - python 3.6
Execution Role - oe-lambda-role
# Enable VPC -
VPC - ameintu-vpc
Subnets - ameintu-subnet-private
Security groups - oe-lambda-sg

# Lambda Environment Variable
cfResourceIPaddress = ameintu-LB-1190207452.us-east-1.elb.amazonaws.com
cfpath = 
cfport = 80
cfprotocol = HTTP
cfstackname = amit-project